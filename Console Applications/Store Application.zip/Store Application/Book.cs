﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store_Application
{
    class Book : List
    {
        int bookitem;
        int price;
        int qty;
    
        
     public void Add()
        {
            Console.Write("Book Item:- ");
            bookitem = Convert.ToInt32(Console.ReadLine());
            Console.Write("Book Price:-");
            price = Convert.ToInt32(Console.ReadLine());
            Console.Write("Qty:- ");
            qty = Convert.ToInt32(Console.ReadLine());
        }
        public void Fetch()
        {
            Console.WriteLine($"Book Items:- {bookitem}");
            Console.WriteLine($"Book Price:- {price}");
            Console.WriteLine($"Qty:- {qty}");

        }
        public void Remove()
        {
           
        }
        public void Discount()
        {
            if(bookitem > 10)
            {
                int discount = 15;
                int amount = price - (price * discount / 100);
                Console.WriteLine($"Amount:- {price}");
                Console.WriteLine($"You get {discount}% discount");
                Console.WriteLine($"After Discount Amount:- {amount}");
            }
            else if(bookitem == 10)
            {
                int discount = 10;
                int amount = price - (price * discount / 100);
                Console.WriteLine($"Amount:- {price}");
                Console.WriteLine($"You get {discount}% discount");
                Console.WriteLine($"Total Amount:- {amount}");
            }
            else
            {
                Console.WriteLine($"Total Amount:- {price}");
            }
        }
        


        
    }
}
