﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace Store_Application
{
    class Program
    {
        static void Main(string[] args)
        {
            Book b = new Book();
            b.Add();
            b.Fetch();
            b.Discount();
            

            /*Product p = new Product();
             p.display();
             Console.Read();*/
            NoteBook nb = new NoteBook();
            nb.Add();
            nb.Fetch();
            nb.Discount();

            Pen p = new Pen();
            p.Add();
            p.Fetch();
            p.Discount();
            Console.Read();

        }
    }
}
