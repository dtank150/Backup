﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store_Application
{
    class Pen : List
    {
        int Penitems;
        int Rate;
        int Qty;
        public void penstore()
        {
            List<string> Pen = new List<string>();
        }
        public void Add() {
            Console.Write("Pen Item:- ");
            Penitems = Convert.ToInt32(Console.ReadLine());
            Console.Write("Pen Price:-");
            Rate = Convert.ToInt32(Console.ReadLine());
            Console.Write("Qty:- ");
            Qty = Convert.ToInt32(Console.ReadLine());
        }
        public void Fetch() 
        {
            Console.WriteLine($"Pen Items:- {Penitems}");
            Console.WriteLine($"Pen Price:- {Rate}");
            Console.WriteLine($"Qty:- {Qty}");
        }
        public void Remove() { }
        public void Discount()
        {
            if (Penitems > 10)
            {
                int discount = 15;
                int amount = Rate - (Rate * discount / 100);
                Console.WriteLine($"Amount:- {Rate}");
                Console.WriteLine($"You get {discount}% discount");
                Console.WriteLine($"After Discount Amount:- {amount}");
            }
            else if (Penitems == 10)
            {
                int discount = 10;
                int amount = Rate - (Rate * discount / 100);
                Console.WriteLine($"Amount:- {Rate}");
                Console.WriteLine($"You get {discount}% discount");
                Console.WriteLine($"Total Amount:- {amount}");
            }
            else
            {
                Console.WriteLine($"Total Amount:- {Rate}");
            }
        }
    }
}
