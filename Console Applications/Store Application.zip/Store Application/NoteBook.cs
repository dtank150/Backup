﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Store_Application
{
    class NoteBook : List
    {
        int Notebookitems;
        int Rate;
        int Qty;
        public void NoteBookStore()
        {
            List<string> Notebook = new List<string>();
        }
        public void Add() 
        {
            Console.Write("Notebook Item:- ");
            Notebookitems = Convert.ToInt32(Console.ReadLine());
            Console.Write("Notebook Price:-");
            Rate = Convert.ToInt32(Console.ReadLine());
            Console.Write("Qty:- ");
            Qty = Convert.ToInt32(Console.ReadLine());
        }
        public void Fetch()
        {
            Console.WriteLine($"Notebook Items:- {Notebookitems}");
            Console.WriteLine($"Notebook Price:- {Rate}");
            Console.WriteLine($"Qty:- {Qty}");
        }
        public void Remove() { }
        public void Discount()
        {
            if (Notebookitems > 10)
            {
                int discount = 20;
                int amount = Rate - (Rate * discount / 100);
                Console.WriteLine($"Amount:- {Rate}");
                Console.WriteLine($"You get {discount}% discount");
                Console.WriteLine($"After Discount Amount:- {amount}");
            }
            else if (Notebookitems == 10)
            {
                int discount = 10;
                int amount = Rate - (Rate * discount / 100);
                Console.WriteLine($"Amount:- {Rate}");
                Console.WriteLine($"You get {discount}% discount");
                Console.WriteLine($"Total Amount:- {amount}");
            }
            else
            {
                Console.WriteLine($"Total Amount:- {Rate}");
            }
        }
    }
}
